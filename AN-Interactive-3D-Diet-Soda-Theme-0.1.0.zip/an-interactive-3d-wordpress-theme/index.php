<?php
/** Fallback template. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
?>
<main class="site-main">
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
  <article <?php post_class(); ?>><h1><?php the_title(); ?></h1><?php the_content(); ?></article>
<?php endwhile; else : ?><p><?php esc_html_e( 'Nothing to display yet.', 'an-interactive-3d' ); ?></p><?php endif; ?>
</main>
<?php get_footer(); ?>
